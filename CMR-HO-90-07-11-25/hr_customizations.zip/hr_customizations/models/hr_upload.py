import logging

from dateutil.relativedelta import relativedelta

from odoo import models,fields,api,_
import base64
from io import BytesIO
import openpyxl
import pytz
from datetime import datetime, timedelta
from odoo.exceptions import UserError
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT, DEFAULT_SERVER_DATETIME_FORMAT
import calendar
import traceback
_logger = logging.getLogger(__name__)


class Hrupload(models.Model):
    _name = "hr.upload"


    date = fields.Date('Date')
    employee_code = fields.Char('Employee Code')
    # your_datetime = fields.Datetime(string='Check in', compute='_compute_your_datetime',store=True)
    # your_checkout_datetime = fields.Datetime(string='Check-Out', compute='_compute_your_checkout_datetime',
    #                                          store=True)
    your_datetime = fields.Datetime(string='Check-In')
    your_checkout_datetime = fields.Datetime(string='Check-Out')
    employee_name = fields.Many2one('hr.employee', string="Employee Name", required=True)
    check_in_attendance = fields.Char(string="Check In")
    check_out_attendance = fields.Char(string="Check Out")
    difference_check_in = fields.Float(string="IN Difference (mins)", compute='_compute_attendance', store=True)
    difference_check_out = fields.Float(string="OUT Difference (mins)", compute='_compute_attendance', store=True)
    total_working_hours = fields.Char(string="Total Working Hours", compute='_compute_attendance', store=True)
    attendance_status = fields.Selection([
        ('grace', 'Grace'),
        ('early', 'Early'),
        ('late', 'Late'),
        ('others', 'Others')
    ], string="Attendance Status", compute='_compute_attendance', store=True)
    late_deduction = fields.Float(string="Late Deduction(Rupees)", compute="_compute_late_deduction", store=True)
    overtime_amount = fields.Float(string="Overtime Amount (₹)", compute="_compute_overtime_amount", store=True)
    morning_session = fields.Selection([
        ('Present', 'Present'),
        ('Absent', 'Absent')
    ], string="Morning Session", compute='_compute_sessions', store=True)
    afternoon_session = fields.Selection([
        ('Present', 'Present'),
        ('Absent', 'Absent')
    ], string="Afternoon Session", compute='_compute_sessions', store=True)

    full_day_status = fields.Char(string="Full Day Status", compute='_compute_full_day_status', store=True)

    ctc_type = fields.Selection([
        ('with_bonus', 'With Bonus'),
        ('without_bonus', 'Without Bonus'),
        ('non_ctc', 'Non Ctc'),
    ], string='CTC Type')

    @api.onchange('employee_name')
    def _onchange_employee_name(self):
        if self.employee_name:
            self.ctc_type = self.employee_name.ctc_type


    @api.depends('total_working_hours', 'morning_session', 'afternoon_session', 'check_out_attendance')
    def _compute_full_day_status(self):
        for rec in self:
            # Convert working hours safely to float
            try:
                total_hours = float(rec.total_working_hours or 0.0)
            except (ValueError, TypeError):
                total_hours = 0.0

            # If no checkout → mark afternoon as absent
            if not rec.check_out_attendance:
                rec.afternoon_session = 'Absent'

            # Determine full day status
            if total_hours >= 9.0:
                rec.full_day_status = 'Present (Full Day)'
            else:
                morning = rec.morning_session or 'Absent'
                afternoon = rec.afternoon_session or 'Absent'

                if morning == 'Present' and afternoon == 'Present':
                    rec.full_day_status = 'FIRST SESSION PRESENT AND SECOND SESSION PRESENT'
                elif morning == 'Present' and afternoon == 'Absent':
                    rec.full_day_status = 'FIRST SESSION PRESENT AND SECOND SESSION ABSENT'
                elif morning == 'Absent' and afternoon == 'Present':
                    rec.full_day_status = 'FIRST SESSION ABSENT AND SECOND SESSION PRESENT'
                else:
                    rec.full_day_status = 'Absent (Full Day)'

    @api.depends('check_out_attendance')
    def _compute_overtime_amount(self):
        for rec in self:
            rec.overtime_amount = 0.0
            if not rec.check_out_attendance:
                continue

            try:
                # Convert check_out_attendance (HH:MM) to datetime.time
                check_out_time = datetime.strptime(rec.check_out_attendance, "%H:%M").time()
            except Exception:
                rec.overtime_amount = 0.0
                continue

            # Fetch all overtime rules
            overtime_rules = self.env['hr.overtime.master'].search([])

            for rule in overtime_rules:
                try:
                    start_time = datetime.strptime(rule.start_time, "%H:%M").time()
                    end_time = datetime.strptime(rule.end_time, "%H:%M").time()
                except Exception:
                    continue

                # ✅ If check-out is between start and end → assign overtime
                if start_time <= check_out_time <= end_time:
                    rec.overtime_amount = rule.overtime_amount
                    break

    @api.depends('check_in_attendance', 'check_out_attendance')
    def _compute_attendance(self):
        shift_start = datetime.strptime('10:00', '%H:%M')
        grace_end = datetime.strptime('10:15', '%H:%M')
        shift_end = datetime.strptime('19:00', '%H:%M')

        for rec in self:
            rec.difference_check_in = 0.0
            rec.difference_check_out = 0.0
            rec.total_working_hours = "0:00"
            rec.attendance_status = 'others'  # Default only in compute

            # --- Check-in minutes & status ---
            if rec.check_in_attendance:
                try:
                    check_in_time = datetime.strptime(rec.check_in_attendance, '%H:%M')
                    if check_in_time <= shift_start:
                        rec.difference_check_in = (shift_start - check_in_time).total_seconds() / 60
                        rec.attendance_status = 'early'
                    elif shift_start < check_in_time <= grace_end:
                        rec.difference_check_in = 0.0
                        rec.attendance_status = 'grace'
                    else:
                        rec.difference_check_in = -((check_in_time - grace_end).total_seconds() / 60)
                        rec.attendance_status = 'late'
                except:
                    rec.attendance_status = 'others'
            else:
                # No check-in → mark as others
                rec.attendance_status = 'others'

            # --- Check-out minutes ---
            if rec.check_out_attendance:
                try:
                    check_out_time = datetime.strptime(rec.check_out_attendance, '%H:%M')
                    if check_out_time >= shift_end:
                        rec.difference_check_out = (check_out_time - shift_end).total_seconds() / 60
                    else:
                        rec.difference_check_out = -((shift_end - check_out_time).total_seconds() / 60)
                except:
                    rec.difference_check_out = 0.0

            # --- Total working hours ---
            if rec.check_in_attendance and rec.check_out_attendance:
                try:
                    check_in_time = datetime.strptime(rec.check_in_attendance, '%H:%M')
                    check_out_time = datetime.strptime(rec.check_out_attendance, '%H:%M')
                    total_seconds = (check_out_time - check_in_time).total_seconds()
                    if total_seconds < 0:
                        total_seconds += 24 * 3600
                    hours = int(total_seconds // 3600)
                    minutes = int((total_seconds % 3600) // 60)
                    rec.total_working_hours = f"{hours}:{minutes:02d}"
                except:
                    rec.total_working_hours = "0:00"

    @api.depends('check_in_attendance')
    def _compute_late_deduction(self):
        for rec in self:
            rec.late_deduction = 0.0
            if rec.check_in_attendance:
                try:
                    # Convert check_in_attendance (HH:MM) to datetime.time
                    check_in_time = datetime.strptime(rec.check_in_attendance, "%H:%M").time()

                    masters = self.env['hr.late.deduction.master'].search([])
                    for master in masters:
                        start_time = datetime.strptime(master.start_time, "%H:%M").time()
                        end_time = datetime.strptime(master.end_time, "%H:%M").time()

                        if start_time <= check_in_time <= end_time:
                            rec.late_deduction = master.deduction_amount
                            break
                except Exception:
                    rec.late_deduction = 0.0
            else:
                rec.late_deduction = 0.0

    @api.depends('check_in_attendance')
    def _compute_sessions(self):
        for rec in self:
            if rec.check_in_attendance:
                try:
                    check_in_time = datetime.strptime(rec.check_in_attendance, "%H:%M")
                    shift_start = datetime.strptime("10:00", "%H:%M")
                    grace_end = datetime.strptime("10:15", "%H:%M")
                    first_session_absent_time = grace_end + timedelta(minutes=75)  # 11:30 AM
                    second_session_absent_time = datetime.strptime("14:15", "%H:%M")  # 2:15 PM

                    # Determine sessions
                    if check_in_time > second_session_absent_time:
                        rec.morning_session = 'Absent'
                        rec.afternoon_session = 'Absent'
                    elif check_in_time > first_session_absent_time:
                        rec.morning_session = 'Absent'
                        rec.afternoon_session = 'Present'
                    else:
                        rec.morning_session = 'Present'
                        rec.afternoon_session = 'Present'

                    if not rec.check_out_attendance:
                        rec.afternoon_session = 'Absent'
                except ValueError:
                    rec.morning_session = 'Absent'
                    rec.afternoon_session = 'Absent'
            else:
                rec.morning_session = 'Absent'
                rec.afternoon_session = 'Absent'


    # @api.depends('date', 'check_in_attendance')
    # def _compute_your_datetime(self):
    #     for record in self:
    #         if record.date:
    #             try:
    #                 # Use check_in time if provided, otherwise default to "00:00"
    #                 check_in_time = record.check_in_attendance if record.check_in_attendance else "00:00"
    #                 # Combine date and time into a string
    #                 datetime_str = f"{record.date} {check_in_time}:00"
    #                 # Parse the combined string into a naive datetime object
    #                 naive_datetime = datetime.strptime(datetime_str, DEFAULT_SERVER_DATETIME_FORMAT)
    #                 # Convert the naive datetime to the user's timezone
    #                 user_tz = self.env.user.tz or 'UTC'
    #                 local_tz = pytz.timezone(user_tz)
    #                 local_dt = local_tz.localize(naive_datetime, is_dst=None)
    #                 # Convert the localized datetime to UTC
    #                 utc_dt = local_dt.astimezone(pytz.UTC)
    #                 # Assign the UTC datetime to the field
    #                 record.your_datetime = fields.Datetime.to_string(utc_dt)
    #             except ValueError:
    #                 record.your_datetime = False
    #         else:
    #             # If date is not provided, set your_datetime to False
    #             record.your_datetime = False
    #
    # @api.depends('date', 'check_out_attendance')
    # def _compute_your_checkout_datetime(self):
    #     for record in self:
    #         if record.date:
    #             try:
    #                 # Use check_out_attendance if available, otherwise default to "00:00"
    #                 checkout_time = record.check_out_attendance or "00:00"
    #
    #                 # Combine date and time into a string
    #                 datetime_str = f"{record.date} {checkout_time}:00"
    #
    #                 # Parse the combined string into a naive datetime object
    #                 naive_datetime = datetime.strptime(datetime_str, DEFAULT_SERVER_DATETIME_FORMAT)
    #
    #                 # Convert to user's timezone and then to UTC
    #                 user_tz = self.env.user.tz or 'UTC'
    #                 local_tz = pytz.timezone(user_tz)
    #                 local_dt = local_tz.localize(naive_datetime, is_dst=None)
    #                 utc_dt = local_dt.astimezone(pytz.UTC)
    #
    #                 # Assign the UTC datetime
    #                 record.your_checkout_datetime = fields.Datetime.to_string(utc_dt)
    #             except ValueError:
    #                 record.your_checkout_datetime = False
    #         else:
    #             record.your_checkout_datetime = False


    def open_upload_wizard(self):
        return {
            'name': 'Upload HR Data',
            'type': 'ir.actions.act_window',
            'res_model': 'hr.upload.wizard',
            'view_mode': 'form',
            'target': 'new',
        }



class HrUploadWizard(models.TransientModel):
    _name = "hr.upload.wizard"
    _description = "HR Upload Wizard"

    file = fields.Binary(string="File", required=True)
    filename = fields.Char(string="File Name")



    def action_upload(self):
            """Uploads attendance Excel file and creates hr.upload, hr.attendance, and hr.leave records with EL/LOP rules.
            Integrates with hr.contract.leaves_available for non_ctc employees only.
            """
            if not self.file:
                raise UserError(_("Please upload a file."))

            try:
                wb = openpyxl.load_workbook(
                    filename=BytesIO(base64.b64decode(self.file)),
                    read_only=True
                )
                ws = wb.active

                hr_upload_obj = self.env['hr.upload']
                employee_obj = self.env['hr.employee']
                attendance_obj = self.env['hr.attendance']
                leave_obj = self.env['hr.leave']

                el_type = self.env['hr.leave.type'].search([('name', '=', 'EL')], limit=1)
                lop_type = self.env['hr.leave.type'].search([('name', '=', 'LOP')], limit=1)
                if not el_type or not lop_type:
                    raise UserError(_("Please configure both 'EL' and 'LOP' in Time Off Types."))

                user_tz = self.env.user.tz or 'Asia/Kolkata'
                tz = pytz.timezone(user_tz)

                def combine_datetime(date_part, time_value):
                    if not time_value:
                        return False
                    if isinstance(time_value, datetime):
                        return time_value
                    elif isinstance(time_value, (float, int)):
                        from openpyxl.utils.datetime import from_excel
                        dt = from_excel(time_value)
                        return datetime.combine(date_part, dt.time())
                    elif isinstance(time_value, str):
                        for fmt in ("%H:%M:%S", "%H:%M"):
                            try:
                                t = datetime.strptime(time_value.strip(), fmt).time()
                                return datetime.combine(date_part, t)
                            except Exception:
                                continue
                        return False
                    else:
                        return False

                row_number = 1
                for row in ws.iter_rows(min_row=2, values_only=True):
                    row_number += 1

                    employee_code = row[1]
                    employee_name = row[2]
                    date_value = row[9]
                    check_in = row[12]
                    check_out = row[14]

                    if not employee_code:
                        raise UserError(_("Row %d: Employee code is missing.") % row_number)
                    if not employee_name:
                        raise UserError(_("Row %d: Employee name is missing.") % row_number)

                    employee_name = str(employee_name).strip()
                    try:
                        employee_code_str = str(int(employee_code))
                    except Exception:
                        employee_code_str = str(employee_code).strip()

                    employee_exact = employee_obj.search([
                        ('cmr_code', '=', employee_code_str),
                        ('name', '=', employee_name)
                    ], limit=1)

                    if not employee_exact:
                        raise UserError(_(
                            "Row %d: No employee found with code '%s' and name '%s'."
                        ) % (row_number, employee_code_str, employee_name))

                    employee = employee_exact

                    formatted_date = False
                    if isinstance(date_value, datetime):
                        formatted_date = date_value.date()
                    elif isinstance(date_value, str):
                        for fmt in ("%d-%b-%Y", "%Y-%m-%d", "%d/%m/%Y", "%m/%d/%Y", "%d/%m/%y"):
                            try:
                                formatted_date = datetime.strptime(date_value, fmt).date()
                                break
                            except Exception:
                                continue
                    if not formatted_date:
                        raise UserError(_("Row %d: Invalid date format '%s'.") % (row_number, date_value))

                    check_in_dt = combine_datetime(formatted_date, check_in)
                    check_out_dt = combine_datetime(formatted_date, check_out)

                    check_in_utc = check_out_utc = False
                    if check_in_dt:
                        check_in_utc = tz.localize(check_in_dt).astimezone(pytz.UTC).replace(tzinfo=None)
                    if check_out_dt:
                        check_out_utc = tz.localize(check_out_dt).astimezone(pytz.UTC).replace(tzinfo=None)

                    upload_rec = hr_upload_obj.create({
                        'employee_name': employee.id,
                        'ctc_type': employee.ctc_type,
                        'employee_code': employee_code_str,
                        'date': formatted_date,
                        'check_in_attendance': check_in,
                        'check_out_attendance': check_out,
                        'your_datetime': check_in_utc,
                        'your_checkout_datetime': check_out_utc,
                    })

                    morning = upload_rec.morning_session or ''
                    afternoon = upload_rec.afternoon_session or ''
                    leave_duration = 0.0
                    half_day = False

                    if morning == 'Absent' and afternoon == 'Absent':
                        leave_duration = 1.0
                    elif morning == 'Absent' or afternoon == 'Absent':
                        leave_duration = 0.5
                        half_day = True

                    # ✅ Only for Non-CTC employees
                    if leave_duration > 0 and employee.ctc_type == 'non_ctc':
                        existing_leave = leave_obj.search([
                            ('employee_id', '=', employee.id),
                            ('request_date_from', '=', formatted_date),
                            ('request_date_to', '=', formatted_date),
                            ('state', '!=', 'refuse')
                        ], limit=1)
                        if existing_leave:
                            continue

                        # Fetch active contract
                        contract = self.env['hr.contract'].search([
                            ('employee_id', '=', employee.id),
                            ('state', '=', 'open')
                        ], limit=1)

                        remaining_el = 0.0
                        if contract:
                            remaining_el = contract.leaves_available or 0.0

                        def create_and_validate_leave(leave_type, days, half_day=False, period=False):
                            vals = {
                                'name': f"Auto Leave {formatted_date}",
                                'employee_id': employee.id,
                                'holiday_status_id': leave_type.id,
                                'request_date_from': formatted_date,
                                'request_date_to': formatted_date,
                                'number_of_days': days,
                                'payslip_state': 'done'
                            }
                            if half_day:
                                vals.update({
                                    'request_unit_half': True,
                                    'request_date_from_period': period,
                                })
                            leave_rec = leave_obj.create(vals)
                            if leave_rec.state == 'draft':
                                leave_rec.action_confirm()
                            if leave_rec.state in ['confirm', 'validate1']:
                                leave_rec.action_validate()
                            return leave_rec

                        # Deduction Logic
                        if remaining_el >= leave_duration:
                            create_and_validate_leave(
                                el_type, leave_duration, half_day,
                                'am' if half_day and morning == 'Absent' else 'pm' if half_day else False
                            )
                            if contract:
                                contract.leaves_available -= leave_duration

                        elif 0 < remaining_el < leave_duration:
                            create_and_validate_leave(el_type, remaining_el)
                            lop_days = leave_duration - remaining_el
                            create_and_validate_leave(lop_type, lop_days)
                            if contract:
                                contract.leaves_available = 0.0

                        else:
                            create_and_validate_leave(
                                lop_type, leave_duration, half_day,
                                'am' if half_day and morning == 'Absent' else 'pm' if half_day else False
                            )

                        # Ensure leaves_available never negative
                        if contract and contract.leaves_available < 0:
                            contract.leaves_available = 0.0

                    # Create Attendance
                    if check_in_utc and check_out_utc:
                        open_attendance = attendance_obj.search([
                            ('employee_id', '=', employee.id),
                            ('check_out', '=', False)
                        ], limit=1)
                        if open_attendance:
                            open_attendance.write({'check_out': fields.Datetime.to_string(check_out_utc)})
                        else:
                            attendance_obj.create({
                                'employee_id': employee.id,
                                'date': formatted_date,
                                'check_in': fields.Datetime.to_string(check_in_utc),
                                'check_out': fields.Datetime.to_string(check_out_utc),
                            })

            except Exception as e:
                raise UserError(_('Upload failed: %s') % e)

    # Latest Code 28-10-2025 - 06:11 pm
    # def action_upload(self):
    #     """Uploads attendance Excel file and creates hr.upload, hr.attendance, and hr.leave records with EL/LOP rules."""
    #     if not self.file:
    #         raise UserError(_("Please upload a file."))
    #
    #     try:
    #         wb = openpyxl.load_workbook(
    #             filename=BytesIO(base64.b64decode(self.file)),
    #             read_only=True
    #         )
    #         ws = wb.active
    #
    #         hr_upload_obj = self.env['hr.upload']
    #         employee_obj = self.env['hr.employee']
    #         attendance_obj = self.env['hr.attendance']
    #         leave_obj = self.env['hr.leave']
    #
    #         # === Verify Leave Types Exist ===
    #         el_type = self.env['hr.leave.type'].search([('name', '=', 'EL')], limit=1)
    #         lop_type = self.env['hr.leave.type'].search([('name', '=', 'LOP')], limit=1)
    #         if not el_type or not lop_type:
    #             raise UserError(_("Please configure both 'EL' and 'LOP' in Time Off Types."))
    #
    #         user_tz = self.env.user.tz or 'Asia/Kolkata'
    #         tz = pytz.timezone(user_tz)
    #
    #         # Helper: combine Excel date + time
    #         def combine_datetime(date_part, time_value):
    #             if not time_value:
    #                 return False
    #             if isinstance(time_value, datetime):
    #                 return time_value
    #             elif isinstance(time_value, (float, int)):
    #                 # Excel float to time
    #                 from openpyxl.utils.datetime import from_excel
    #                 dt = from_excel(time_value)
    #                 return datetime.combine(date_part, dt.time())
    #             elif isinstance(time_value, str):
    #                 for fmt in ("%H:%M:%S", "%H:%M"):
    #                     try:
    #                         t = datetime.strptime(time_value.strip(), fmt).time()
    #                         return datetime.combine(date_part, t)
    #                     except Exception:
    #                         continue
    #                 return False
    #             else:
    #                 return False
    #
    #         row_number = 1
    #         for row in ws.iter_rows(min_row=2, values_only=True):
    #             row_number += 1
    #
    #             # === Extract Excel values ===
    #             employee_code = row[1]
    #             employee_name = row[2]
    #             date_value = row[9]
    #             check_in = row[12]
    #             check_out = row[14]
    #
    #             # === Validation ===
    #             if not employee_code:
    #                 raise UserError(_("Row %d: Employee code is missing.") % row_number)
    #             if not employee_name:
    #                 raise UserError(_("Row %d: Employee name is missing.") % row_number)
    #
    #             employee_name = str(employee_name).strip()
    #             try:
    #                 employee_code_str = str(int(employee_code))
    #             except Exception:
    #                 employee_code_str = str(employee_code).strip()
    #
    #             employee_exact = employee_obj.search([
    #                 ('cmr_code', '=', employee_code_str),
    #                 ('name', '=', employee_name)
    #             ], limit=1)
    #
    #             if not employee_exact:
    #                 raise UserError(_(
    #                     "Row %d: No employee found with code '%s' and name '%s'."
    #                 ) % (row_number, employee_code_str, employee_name))
    #
    #             employee = employee_exact
    #
    #             # === Convert Date ===
    #             formatted_date = False
    #             if isinstance(date_value, datetime):
    #                 formatted_date = date_value.date()
    #             elif isinstance(date_value, str):
    #                 for fmt in ("%d-%b-%Y", "%Y-%m-%d", "%d/%m/%Y", "%m/%d/%Y", "%d/%m/%y"):
    #                     try:
    #                         formatted_date = datetime.strptime(date_value, fmt).date()
    #                         break
    #                     except Exception:
    #                         continue
    #             if not formatted_date:
    #                 raise UserError(_("Row %d: Invalid date format '%s'.") % (row_number, date_value))
    #
    #             # === Combine Date + Time ===
    #             check_in_dt = combine_datetime(formatted_date, check_in)
    #             check_out_dt = combine_datetime(formatted_date, check_out)
    #
    #             check_in_utc = check_out_utc = False
    #             if check_in_dt:
    #                 check_in_utc = tz.localize(check_in_dt).astimezone(pytz.UTC).replace(tzinfo=None)
    #             if check_out_dt:
    #                 check_out_utc = tz.localize(check_out_dt).astimezone(pytz.UTC).replace(tzinfo=None)
    #
    #             # === Create hr.upload Record ===
    #             upload_rec = hr_upload_obj.create({
    #                 'employee_name': employee.id,
    #                 'ctc_type': employee.ctc_type,
    #                 'employee_code': employee_code_str,
    #                 'date': formatted_date,
    #                 'check_in_attendance': check_in,
    #                 'check_out_attendance': check_out,
    #                 'your_datetime': check_in_utc,
    #                 'your_checkout_datetime': check_out_utc,
    #             })
    #
    #             # === Determine Leave Type (EL/LOP) ===
    #             morning = upload_rec.morning_session or ''
    #             afternoon = upload_rec.afternoon_session or ''
    #             leave_duration = 0.0
    #             half_day = False
    #
    #             if morning == 'Absent' and afternoon == 'Absent':
    #                 leave_duration = 1.0
    #             elif morning == 'Absent' or afternoon == 'Absent':
    #                 leave_duration = 0.5
    #                 half_day = True
    #
    #             if leave_duration > 0:
    #                 existing_leave = leave_obj.search([
    #                     ('employee_id', '=', employee.id),
    #                     ('request_date_from', '=', formatted_date),
    #                     ('request_date_to', '=', formatted_date),
    #                     ('state', '!=', 'refuse')
    #                 ], limit=1)
    #                 if existing_leave:
    #                     continue
    #
    #                 leave_type = lop_type
    #                 remaining_el = 0.0
    #
    #                 if employee.ctc_type == 'non_ctc':
    #                     first_day = formatted_date.replace(day=1)
    #                     last_day = (first_day + relativedelta(months=1)) - timedelta(days=1)
    #                     total_els = leave_obj.search_read([
    #                         ('employee_id', '=', employee.id),
    #                         ('holiday_status_id', '=', el_type.id),
    #                         ('request_date_from', '>=', first_day),
    #                         ('request_date_to', '<=', last_day),
    #                         ('state', '!=', 'refuse')
    #                     ], ['number_of_days'])
    #                     total_el_taken = sum(l['number_of_days'] for l in total_els)
    #                     remaining_el = max(3 - total_el_taken, 0.0)
    #
    #                 def create_and_validate_leave(leave_type, days, half_day=False, period=False):
    #                     vals = {
    #                         'name': f"Auto Leave {formatted_date}",
    #                         'employee_id': employee.id,
    #                         'holiday_status_id': leave_type.id,
    #                         'request_date_from': formatted_date,
    #                         'request_date_to': formatted_date,
    #                         'number_of_days': days,
    #                         'payslip_state': 'done'
    #                     }
    #                     if half_day:
    #                         vals.update({
    #                             'request_unit_half': True,
    #                             'request_date_from_period': period,
    #                         })
    #                     leave_rec = leave_obj.create(vals)
    #                     if leave_rec.state == 'draft':
    #                         leave_rec.action_confirm()
    #                     if leave_rec.state in ['confirm', 'validate1']:
    #                         leave_rec.action_validate()
    #
    #                 if remaining_el >= leave_duration:
    #                     create_and_validate_leave(
    #                         el_type, leave_duration, half_day,
    #                         'am' if half_day and morning == 'Absent' else 'pm' if half_day else False
    #                     )
    #                 elif remaining_el > 0 and remaining_el < leave_duration:
    #                     create_and_validate_leave(el_type, remaining_el)
    #                     lop_days = leave_duration - remaining_el
    #                     create_and_validate_leave(lop_type, lop_days)
    #                 else:
    #                     create_and_validate_leave(
    #                         lop_type, leave_duration, half_day,
    #                         'am' if half_day and morning == 'Absent' else 'pm' if half_day else False
    #                     )
    #
    #             # === Create Attendance ===
    #             if check_in_utc and check_out_utc:
    #                 open_attendance = attendance_obj.search([
    #                     ('employee_id', '=', employee.id),
    #                     ('check_out', '=', False)
    #                 ], limit=1)
    #                 if open_attendance:
    #                     open_attendance.write({'check_out': fields.Datetime.to_string(check_out_utc)})
    #                 else:
    #                     attendance_obj.create({
    #                         'employee_id': employee.id,
    #                         'date': formatted_date,
    #                         'check_in': fields.Datetime.to_string(check_in_utc),
    #                         'check_out': fields.Datetime.to_string(check_out_utc),
    #                     })
    #
    #     except Exception as e:
    #         raise UserError(_('Upload failed: %s') % e)

    # 27-10-2025 - 07:00 pm
    # def action_upload(self):
    #     """Uploads attendance Excel file and creates hr.upload, hr.attendance, and hr.leave records with EL/LOP rules."""
    #     if not self.file:
    #         raise UserError(_("Please upload a file."))
    #
    #     try:
    #         wb = openpyxl.load_workbook(
    #             filename=BytesIO(base64.b64decode(self.file)),
    #             read_only=True
    #         )
    #         ws = wb.active
    #
    #         hr_upload_obj = self.env['hr.upload']
    #         employee_obj = self.env['hr.employee']
    #         attendance_obj = self.env['hr.attendance']
    #         leave_obj = self.env['hr.leave']
    #
    #         # === Verify Leave Types Exist ===
    #         el_type = self.env['hr.leave.type'].search([('name', '=', 'EL')], limit=1)
    #         lop_type = self.env['hr.leave.type'].search([('name', '=', 'LOP')], limit=1)
    #         if not el_type or not lop_type:
    #             raise UserError(_("Please configure both 'EL' and 'LOP' in Time Off Types."))
    #
    #         user_tz = self.env.user.tz or 'Asia/Kolkata'
    #         tz = pytz.timezone(user_tz)
    #
    #         row_number = 1
    #         for row in ws.iter_rows(min_row=2, values_only=True):
    #             row_number += 1
    #
    #             # Extract Excel values
    #             employee_code = row[1]
    #             employee_name = row[2]
    #             date_value = row[9]
    #             check_in = row[12]
    #             check_out = row[14]
    #
    #             # ===== Validation =====
    #             if not employee_code:
    #                 raise UserError(_("Row %d: Employee code is missing.") % row_number)
    #             if not employee_name:
    #                 raise UserError(_("Row %d: Employee name is missing.") % row_number)
    #
    #             employee_name = str(employee_name).strip()
    #             try:
    #                 employee_code_str = str(int(employee_code))
    #             except Exception:
    #                 employee_code_str = str(employee_code).strip()
    #
    #             employee_exact = employee_obj.search([
    #                 ('cmr_code', '=', employee_code_str),
    #                 ('name', '=', employee_name)
    #             ], limit=1)
    #
    #             if not employee_exact:
    #                 raise UserError(_(
    #                     "Row %d: No employee found with code '%s' and name '%s'."
    #                 ) % (row_number, employee_code_str, employee_name))
    #
    #             employee = employee_exact
    #
    #             # ===== Date Conversion =====
    #             formatted_date = False
    #             if isinstance(date_value, datetime):
    #                 formatted_date = date_value.date()
    #             elif isinstance(date_value, str):
    #                 for fmt in ("%d-%b-%Y", "%Y-%m-%d", "%d/%m/%Y", "%m/%d/%Y", "%d/%m/%y"):
    #                     try:
    #                         formatted_date = datetime.strptime(date_value, fmt).date()
    #                         break
    #                     except Exception:
    #                         continue
    #
    #             if not formatted_date:
    #                 raise UserError(_("Row %d: Invalid date format '%s'.") % (row_number, date_value))
    #
    #             # ===== Create hr.upload Record =====
    #             upload_rec = hr_upload_obj.create({
    #                 'employee_name': employee.id,
    #                 'ctc_type': employee.ctc_type,
    #                 'employee_code': employee_code_str,
    #                 'date': formatted_date,
    #                 'check_in_attendance': check_in,
    #                 'check_out_attendance': check_out,
    #             })
    #
    #             # ===== Determine Leave Type (EL/LOP) TIME OFF CREATION=====
    #             morning = upload_rec.morning_session or ''
    #             afternoon = upload_rec.afternoon_session or ''
    #             leave_duration = 0.0
    #             half_day = False
    #
    #             if morning == 'Absent' and afternoon == 'Absent':
    #                 leave_duration = 1.0
    #             elif morning == 'Absent' or afternoon == 'Absent':
    #                 leave_duration = 0.5
    #                 half_day = True
    #
    #             if leave_duration > 0:
    #                 # Prevent duplicate leave on same day
    #                 existing_leave = leave_obj.search([
    #                     ('employee_id', '=', employee.id),
    #                     ('request_date_from', '=', formatted_date),
    #                     ('request_date_to', '=', formatted_date),
    #                     ('state', '!=', 'refuse')
    #                 ], limit=1)
    #                 if existing_leave:
    #                     continue
    #
    #                 # Monthly EL/LOP rule
    #                 leave_type = lop_type
    #                 remaining_el = 0.0
    #
    #                 if employee.ctc_type == 'non_ctc':
    #                     first_day = formatted_date.replace(day=1)
    #                     last_day = (first_day + relativedelta(months=1)) - timedelta(days=1)
    #
    #                     total_els = leave_obj.search_read([
    #                         ('employee_id', '=', employee.id),
    #                         ('holiday_status_id', '=', el_type.id),
    #                         ('request_date_from', '>=', first_day),
    #                         ('request_date_to', '<=', last_day),
    #                         ('state', '!=', 'refuse')
    #                     ], ['number_of_days'])
    #
    #                     total_el_taken = sum(l['number_of_days'] for l in total_els)
    #                     remaining_el = max(3 - total_el_taken, 0.0)
    #
    #                 def create_and_validate_leave(leave_type, days, half_day=False, period=False):
    #                     vals = {
    #                         'name': f"Auto Leave {formatted_date}",
    #                         'employee_id': employee.id,
    #                         'holiday_status_id': leave_type.id,
    #                         'request_date_from': formatted_date,
    #                         'request_date_to': formatted_date,
    #                         'number_of_days': days,
    #                     }
    #                     if half_day:
    #                         vals.update({
    #                             'request_unit_half': True,
    #                             'request_date_from_period': period,
    #                         })
    #                     leave_rec = leave_obj.create(vals)
    #
    #                     # Auto-confirm + validate
    #                     if leave_rec.state == 'draft':
    #                         leave_rec.action_confirm()
    #                     if leave_rec.state in ['confirm', 'validate1']:
    #                         leave_rec.action_validate()
    #
    #                 # Case 1: all EL
    #                 if remaining_el >= leave_duration:
    #                     create_and_validate_leave(
    #                         el_type, leave_duration, half_day,
    #                         'am' if half_day and morning == 'Absent' else 'pm' if half_day else False
    #                     )
    #
    #                 # Case 2: split between EL and LOP
    #                 elif remaining_el > 0 and remaining_el < leave_duration:
    #                     # EL part
    #                     create_and_validate_leave(el_type, remaining_el)
    #                     # LOP part
    #                     lop_days = leave_duration - remaining_el
    #                     create_and_validate_leave(lop_type, lop_days)
    #
    #                 # Case 3: all LOP
    #                 else:
    #                     create_and_validate_leave(
    #                         lop_type, leave_duration, half_day,
    #                         'am' if half_day and morning == 'Absent' else 'pm' if half_day else False
    #                     )
    #
    #             # ===== Create Attendance =====
    #             if check_in and check_out:
    #
    #                 def to_datetime_local(date_part, time_value):
    #                     if isinstance(time_value, datetime):
    #                         local_dt = datetime.combine(date_part, time_value.time())
    #                     elif isinstance(time_value, str):
    #                         for fmt in ("%H:%M:%S", "%H:%M"):
    #                             try:
    #                                 t = datetime.strptime(time_value.strip(), fmt).time()
    #                                 local_dt = datetime.combine(date_part, t)
    #                                 break
    #                             except Exception:
    #                                 continue
    #                         else:
    #                             return False
    #                     elif isinstance(time_value, (float, int)):
    #                         from openpyxl.utils.datetime import from_excel
    #                         t = from_excel(time_value).time()
    #                         local_dt = datetime.combine(date_part, t)
    #                     else:
    #                         return False
    #
    #                     local_dt = tz.localize(local_dt)
    #                     return local_dt.astimezone(pytz.UTC)
    #
    #                 check_in_dt = to_datetime_local(formatted_date, check_in)
    #                 check_out_dt = to_datetime_local(formatted_date, check_out)
    #
    #                 if not (check_in_dt and check_out_dt):
    #                     continue
    #
    #                 open_attendance = attendance_obj.search([
    #                     ('employee_id', '=', employee.id),
    #                     ('check_out', '=', False)
    #                 ], limit=1)
    #
    #                 if open_attendance:
    #                     open_attendance.write({'check_out': fields.Datetime.to_string(check_out_dt)})
    #                 else:
    #                     attendance_obj.create({
    #                         'employee_id': employee.id,
    #                         'date': formatted_date,
    #                         'check_in': fields.Datetime.to_string(check_in_dt),
    #                         'check_out': fields.Datetime.to_string(check_out_dt),
    #                     })
    #
    #     except Exception as e:
    #         raise UserError(_('Upload failed: %s') % e)



class HrLateDeductionMaster(models.Model):
    _name = "hr.late.deduction.master"
    _description = "Late Deduction Master"
    _order = "start_time asc"

    name = fields.Char(string="Name", required=True)
    start_time = fields.Char(string="Start Time (HH:MM)", required=True)  # Example: 10:10
    end_time = fields.Char(string="End Time (HH:MM)", required=True)  # Example: 10:30
    deduction_amount = fields.Float(string="Deduction Amount", required=True)

class HrMonthlyLateDeduction(models.Model):
    _name = "hr.monthly.late.deduction"
    _description = "Monthly Late Deduction"

    employee_id = fields.Many2one('hr.employee', string="Employee")
    month = fields.Selection(
        [(str(i), calendar.month_name[i]) for i in range(1, 13)],
        string="Month",
        required=True,
        default=lambda self: str(datetime.now().month)
    )

    year = fields.Integer(string="Year", required=True, default=lambda self: datetime.now().year)


    line_ids = fields.One2many(
        'hr.late.deduction.line',
        'monthly_id',
        string="Late Deduction Lines"
    )



    # def action_generate_all_employees(self):
    #     self.ensure_one()
    #     month = self.month
    #     year = self.year
    #
    #     start_date = datetime(year, month, 1)
    #     last_day = calendar.monthrange(year, month)[1]
    #     end_date = datetime(year, month, last_day)
    #
    #     uploads = self.env['hr.upload'].search([
    #         ('date', '>=', start_date.date()),
    #         ('date', '<=', end_date.date()),
    #     ])
    #     employee_ids = uploads.mapped('employee_name.id')
    #
    #     if not employee_ids:
    #         return {
    #             'effect': {
    #                 'fadeout': 'slow',
    #                 'message': 'No uploaded employees found for this period!',
    #                 'type': 'rainbow_man',
    #             }
    #         }
    #
    #     existing = self.search([('month', '=', month), ('year', '=', year)])
    #     existing_emp_ids = existing.mapped('employee_id.id')
    #
    #     created_records = self.env['hr.monthly.late.deduction']
    #     for emp_id in employee_ids:
    #         if emp_id not in existing_emp_ids:
    #             rec = self.create({
    #                 'employee_id': emp_id,
    #                 'month': month,
    #                 'year': year,
    #             })
    #             created_records += rec
    #
    #     if created_records:
    #         return {
    #             'type': 'ir.actions.act_window',
    #             'res_model': 'hr.monthly.late.deduction',
    #             'res_id': created_records[0].id,
    #             'view_mode': 'form',
    #             'target': 'current',
    #         }
    #     else:
    #         return {
    #             'effect': {
    #                 'fadeout': 'slow',
    #                 'message': 'Records already exist for uploaded employees!',
    #                 'type': 'rainbow_man',
    #             }
    #         }

    def action_generate_all_employees(self):
        self.ensure_one()

        # ✅ Clean and convert string to integer
        month = int(self.month)
        year = int(str(self.year).replace(',', ''))

        start_date = datetime(year, month, 1)
        last_day = calendar.monthrange(year, month)[1]
        end_date = datetime(year, month, last_day)

        uploads = self.env['hr.upload'].search([
            ('date', '>=', start_date.date()),
            ('date', '<=', end_date.date()),
        ])
        employee_ids = uploads.mapped('employee_name.id')

        if not employee_ids:
            return {
                'effect': {
                    'fadeout': 'slow',
                    'message': 'No uploaded employees found for this period!',
                    'type': 'rainbow_man',
                }
            }

        # Create lines for each employee
        line_vals = []
        for emp_id in employee_ids:
            line_vals.append((0, 0, {
                'employee_id': emp_id,
                'late_days': 0,
                'late_hours': 0.0,
                'deduction_amount': 0.0,
            }))

        # Update current record with lines
        self.line_ids = [(5, 0, 0)] + line_vals  # clear old + add new

        return {
            'effect': {
                'fadeout': 'slow',
                'message': f'{len(employee_ids)} Employee Records Loaded!',
                'type': 'rainbow_man',
            }
        }

class HrLateDeductionLine(models.Model):
    _name = "hr.late.deduction.line"
    _description = "Late Deduction Line"

    monthly_id = fields.Many2one('hr.monthly.late.deduction', string="Monthly Record")
    employee_id = fields.Many2one('hr.employee', string="Employee")
    late_days = fields.Integer(string="Late Days")
    late_hours = fields.Float(string="Late Hours")
    deduction_amount = fields.Float(string="Deduction Amount (₹)", compute="_compute_total_late_deduction",store=True)

    month = fields.Selection(
        related='monthly_id.month',
        string="Month",
        store=True,
        readonly=True
    )
    year = fields.Integer(
        related='monthly_id.year',
        string="Year",
        store=True,
        readonly=True
    )

    @api.depends('employee_id', 'monthly_id.month', 'monthly_id.year')
    def _compute_total_late_deduction(self):
        """Compute total monthly deduction for each employee based on hr.upload."""
        for rec in self:
            rec.deduction_amount = 0.0  # default
            if not rec.employee_id or not rec.monthly_id:
                continue

            # Safely get month & year
            try:
                month = int(rec.month)
                year = int(str(rec.year).replace(',', ''))
            except Exception:
                continue

            start_date = datetime(year, month, 1)
            last_day = calendar.monthrange(year, month)[1]
            end_date = datetime(year, month, last_day)

            # ✅ Search all hr.upload entries for that employee in the month
            uploads = self.env['hr.upload'].search([
                ('employee_name', '=', rec.employee_id.name),
                ('date', '>=', start_date.date()),
                ('date', '<=', end_date.date()),
            ])

            # ✅ Compute total late deduction
            rec.deduction_amount = sum(u.late_deduction for u in uploads)

            # Optional: if you want to count number of days with deductions


class HrOvertimeMaster(models.Model):
    _name = "hr.overtime.master"
    _description = "Overtime Master"
    _order = "start_time asc"

    name = fields.Char(string="Name", required=True)
    start_time = fields.Char(string="Start Time (HH:MM)", required=True)  # e.g. 18:00
    end_time = fields.Char(string="End Time (HH:MM)", required=True)      # e.g. 20:00
    overtime_amount = fields.Float("Overtime Amount (₹)")

class HrMonthlyOvertime(models.Model):
    _name = "hr.monthly.overtime"
    _description = "Monthly Overtime"

    employee_id = fields.Many2one('hr.employee', string="Employee")
    month = fields.Selection(
        [(str(i), calendar.month_name[i]) for i in range(1, 13)],
        string="Month",
        required=True,
        default=lambda self: str(datetime.now().month)
    )
    year = fields.Integer(string="Year", required=True, default=lambda self: datetime.now().year)

    line_ids = fields.One2many('hr.overtime.line', 'monthly_id', string="Overtime Lines")

    def action_generate_all_employees(self):
        self.ensure_one()
        month = int(self.month)
        year = int(self.year)

        start_date = datetime(year, month, 1)
        last_day = calendar.monthrange(year, month)[1]
        end_date = datetime(year, month, last_day)

        uploads = self.env['hr.upload'].search([
            ('date', '>=', start_date.date()),
            ('date', '<=', end_date.date()),
        ])
        employee_ids = uploads.mapped('employee_name.id')

        if not employee_ids:
            return {
                'effect': {
                    'fadeout': 'slow',
                    'message': 'No uploaded employees found for this period!',
                    'type': 'rainbow_man',
                }
            }

        line_vals = []
        for emp_id in employee_ids:
            line_vals.append((0, 0, {
                'employee_id': emp_id,

                'overtime_amount': 0.0,
            }))

        self.line_ids = [(5, 0, 0)] + line_vals

        return {
            'effect': {
                'fadeout': 'slow',
                'message': f'{len(employee_ids)} Employee Overtime Records Loaded!',
                'type': 'rainbow_man',
            }
        }

class HrOvertimeLine(models.Model):
    _name = "hr.overtime.line"
    _description = "Overtime Line"

    monthly_id = fields.Many2one('hr.monthly.overtime', string="Monthly Record")
    employee_id = fields.Many2one('hr.employee', string="Employee")

    overtime_amount = fields.Float(string="Overtime Amount (₹)", compute="_compute_total_overtime", store=True)

    month = fields.Selection(related='monthly_id.month', store=True, readonly=True)
    year = fields.Integer(related='monthly_id.year', store=True, readonly=True)

    @api.depends('employee_id', 'monthly_id.month', 'monthly_id.year')
    def _compute_total_overtime(self):
        """Compute total monthly overtime for each employee based on hr.upload."""
        for rec in self:
            rec.overtime_amount = 0.0
            if not rec.employee_id or not rec.monthly_id:
                continue

            month = int(rec.month)
            year = int(rec.year)
            start_date = datetime(year, month, 1)
            last_day = calendar.monthrange(year, month)[1]
            end_date = datetime(year, month, last_day)

            uploads = self.env['hr.upload'].search([
                ('employee_name', '=', rec.employee_id.name),
                ('date', '>=', start_date.date()),
                ('date', '<=', end_date.date()),
            ])

            rec.overtime_amount = sum(u.overtime_amount for u in uploads)













