{
    'name': 'CMR New Recruitments',
    'version': '1.0',
    'summary': 'Customizions on new Recruitments',
    'depends': ['base', 'hr_recruitment', 'hr','survey', 'mail'],
    'data': [
        'security/ir.model.access.csv',
        'data/mail_data.xml',
        'data/mail_data_appointment.xml',
        'views/hr_applicant_views.xml',
        'views/hr_employee_views.xml',
        'views/grade_master_menu.xml',
        'views/check_list_views.xml',
        'views/survey_survey_views.xml',
        'views/hr_job_view.xml',
        'views/recruitment_application_report_views.xml',

    ],
    'installable': True,
    'application': False,
}
