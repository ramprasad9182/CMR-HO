from odoo import models,fields,api,_
from odoo.fields import Many2many


class HrApplicant(models.Model):
    _inherit = 'hr.applicant'

    applicant_professional_ids = fields.One2many(
        'professional.details',
        'applicant_id',
        string="Professional Details"
    )
    total_experience = fields.Float(string="Total Years of Experience")

    applicant_reference_ids = fields.One2many('employee.reference', 'applicant_employee_id', string="References")
    applicant_education_ids = fields.One2many('employee.education', 'applicant_employee_id', string="Educational Details")

    shortlisted = fields.Selection([
        ('yes', 'Yes'),
        ('no', 'No'),
    ], string='Shortlisted')


    check_list_ids = fields.Many2many("check.list")
    checklist_tab_visible = fields.Boolean(string="Checklist Tab Visible", default=False)

    checklist_order_line_ids = fields.One2many('hr.applicant.checklist.orderline', 'check_list_id', string="Checklist Documents")
    stage_remark_ids = fields.One2many('hr.applicant.stage.remark', 'applicant_id', string='Stage Remarks')

    document_type = fields.Selection([
        ('job', 'Job'),
        ('appointment', 'Appointment'),
        ('checklist', 'Checklist'),
        ('default','Default'),
    ], string='Document Type', default='job')

    is_stage_initial = fields.Boolean(
        string="Is Initial Stage",
        compute="_compute_is_stage_initial",
        store=False
    )
    on_hold = fields.Boolean(string='On Hold', default=False)






    offer_status = fields.Selection([
        ('accepted', 'Offer Accepted'),
        ('rejected', 'Offer Rejected'),
    ], string="Offer Status", tracking=True)

    is_stage_contract_signed = fields.Boolean(
        string="Is Contract Signed Stage",
        compute="_compute_is_stage_contract_signed",
        store=False
    )



    def action_offer_accepted(self):
        for rec in self:
            rec.offer_status = 'accepted'


    def action_offer_rejected(self):
        for rec in self:
            rec.offer_status = 'rejected'

    @api.depends('stage_id')
    def _compute_is_stage_contract_signed(self):
        for rec in self:
            rec.is_stage_contract_signed = rec.stage_id.name == 'Contract Signed'







    def action_set_on_hold(self):
        for rec in self:
            rec.on_hold = True

    def action_unhold(self):
        for rec in self:
            rec.on_hold = False

    @api.depends('stage_id')
    def _compute_is_stage_initial(self):
        for rec in self:
            rec.is_stage_initial = rec.stage_id.name == 'Contract Proposal'


    def action_quotation_send(self):
        ''' Opens a wizard to compose an email, with relevant mail template loaded by default '''
        self.ensure_one()
        template_id = self.env['ir.model.data']._xmlid_to_res_id(
            'cmr_new_recruitments.email_template_applicant_job_offer', raise_if_not_found=False)
        lang = self.env.context.get('lang')
        template = self.env['mail.template'].browse(template_id)
        if template.lang:
            lang = template._render_lang(self.ids)[self.id]
        ctx = {
            'default_model': 'hr.applicant',
            'default_res_ids': self.ids,
            'default_use_template': bool(template_id),
            'default_template_id': template_id,
            'default_composition_mode': 'comment',
            'mark_so_as_sent': True,
            'custom_layout': "mail.mail_notification_paynow",
            'proforma': self.env.context.get('proforma', False),
            'force_email': True,
            'model_description': self.with_context(lang=lang),
            'document_type_to_set': 'appointment',
        }

        return {
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'mail.compose.message',
            'views': [(False, 'form')],
            'view_id': False,
            'target': 'new',
            'context': ctx,
        }

    def action_appointment_letter_send(self):
        ''' Opens a wizard to compose an email for Appointment Letter '''
        self.ensure_one()
        template_id = self.env['ir.model.data']._xmlid_to_res_id(
            'cmr_new_recruitments.email_template_applicant_appointment_letter', raise_if_not_found=False)
        lang = self.env.context.get('lang')
        template = self.env['mail.template'].browse(template_id)
        if template.lang:
            lang = template._render_lang(self.ids)[self.id]
        ctx = {
            'default_model': 'hr.applicant',
            'default_res_ids': self.ids,
            'default_use_template': bool(template_id),
            'default_template_id': template_id,
            'default_composition_mode': 'comment',
            'mark_so_as_sent': True,
            'custom_layout': "mail.mail_notification_paynow",
            'proforma': self.env.context.get('proforma', False),
            'force_email': True,
            'model_description': self.with_context(lang=lang),
            'document_type_to_set': 'checklist'
        }

        return {
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'mail.compose.message',
            'views': [(False, 'form')],
            'view_id': False,
            'target': 'new',
            'context': ctx,
        }

    @api.model
    def _get_next_stage(self, current_stage):
        return self.env['hr.recruitment.stage'].search([
            ('sequence', '>', current_stage.sequence)
        ], order='sequence asc', limit=1)

    def write(self, vals):
        res = super().write(vals)
        if 'shortlisted' in vals and vals['shortlisted'] == 'yes':
            for applicant in self:
                next_stage = self._get_next_stage(applicant.stage_id)
                if next_stage:
                    applicant.stage_id = next_stage.id
                    applicant.shortlisted = False
                else:
                    pass
        return res




    def create_employee_from_applicant(self):
        # Call the original method to create the employee
        res = super(HrApplicant, self).create_employee_from_applicant()

        for applicant in self:
            applicant._onchange_applicant_lines()
            if applicant.emp_id:
                employee = applicant.emp_id
                applicant.emp_id._compute_grade()
                # 1. Copy Professional Details
                for line in applicant.applicant_professional_ids:
                    line.copy({
                        'employee_id': applicant.emp_id.id,
                        'applicant_id': False
                    })

                # 2. Copy Reference Details
                for ref in applicant.applicant_reference_ids:
                    ref.copy({
                        'employee_id': applicant.emp_id.id,
                        'applicant_employee_id': False
                    })

                # 3. Copy Education Details
                for edu in applicant.applicant_education_ids:
                    edu.copy({
                        'employee_id': applicant.emp_id.id,
                        'applicant_employee_id': False
                    })

                # 4. Copy Checklist (Many2many)
                applicant.emp_id.check_list_ids = [(6, 0, applicant.check_list_ids.ids)]

                # 5. Copy Total Experience
                applicant.emp_id.total_experience = applicant.total_experience

                applicant.emp_id.mobile_phone = applicant.partner_phone
                applicant.emp_id.work_phone = applicant.partner_mobile

                # 7. ✅ Auto-create contract
                self.env['hr.contract'].create({
                    'name': employee.name,
                    'employee_id': employee.id,
                    'department_id': employee.department_id.id,
                    'job_id': employee.job_id.id,
                    'date_start': fields.Date.today(),
                    'wage': 0.0,
                })

        return res

    @api.onchange('applicant_education_ids', 'applicant_professional_ids')
    def _onchange_applicant_lines(self):
        """Auto-assign sequence numbers for both educational and professional lines."""
        for idx, line in enumerate(self.applicant_education_ids, start=1):
            line.sequence = idx
        for idx, line in enumerate(self.applicant_professional_ids, start=1):
            line.sequence = idx

    def action_open_checklist_tab(self):
        self.ensure_one()
        self.document_type = 'default'
        self.checklist_tab_visible = True

        return {
            'type': 'ir.actions.act_window',
            'res_model': 'hr.applicant',
            'view_mode': 'form',
            'res_id': self.id,
            'target': 'current',
        }



class MailComposeMessage(models.TransientModel):
    _inherit = 'mail.compose.message'

    def action_send_mail(self):
        # Keep context so we know which button was used
        self = self.with_context(document_type_to_set=self.env.context.get('document_type_to_set'))
        return super().action_send_mail()

    def _action_send_mail_comment(self, res_ids):
        # Send mail using standard method
        messages = super()._action_send_mail_comment(res_ids)

        # Set document_type after email is sent
        doc_type = self.env.context.get('document_type_to_set')
        if self.model == 'hr.applicant' and res_ids and doc_type:
            applicants = self.env['hr.applicant'].browse(res_ids)
            applicants.write({'document_type': doc_type})

        return messages




